"""
forms.py
--------
Flask-WTF form definitions with server-side validation.

Server-side validation is authoritative: client-side (JS) validation in
static/js/main.js is only a UX convenience and must never be trusted alone.
"""

import re

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import (
    DataRequired,
    Email,
    EqualTo,
    Length,
    Regexp,
    ValidationError,
)


def validate_strong_password(form, field):
    """
    Custom validator enforcing a strong-password policy:
    - Minimum 8 characters
    - At least one uppercase letter
    - At least one lowercase letter
    - At least one number
    - At least one special character
    """
    password = field.data or ""
    errors = []

    if len(password) < 8:
        errors.append("at least 8 characters")
    if not re.search(r"[A-Z]", password):
        errors.append("one uppercase letter")
    if not re.search(r"[a-z]", password):
        errors.append("one lowercase letter")
    if not re.search(r"[0-9]", password):
        errors.append("one number")
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>_\-+=\[\]/~`;']", password):
        errors.append("one special character")

    if errors:
        raise ValidationError("Password must contain " + ", ".join(errors) + ".")


class RegisterForm(FlaskForm):
    """Registration form: username, email, password, confirm password."""

    username = StringField(
        "Username",
        validators=[
            DataRequired(),
            Length(min=3, max=25, message="Username must be 3-25 characters."),
            Regexp(
                r"^[A-Za-z0-9_]+$",
                message="Username can only contain letters, numbers, and underscores.",
            ),
        ],
    )
    email = StringField(
        "Email",
        validators=[DataRequired(), Email(message="Enter a valid email address."), Length(max=120)],
    )
    password = PasswordField(
        "Password",
        validators=[DataRequired(), validate_strong_password],
    )
    confirm_password = PasswordField(
        "Confirm Password",
        validators=[
            DataRequired(),
            EqualTo("password", message="Passwords must match."),
        ],
    )
    submit = SubmitField("Create Account")


class LoginForm(FlaskForm):
    """Login form: email, password, remember me."""

    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    remember = BooleanField("Remember Me")
    submit = SubmitField("Sign In")


class OTPForm(FlaskForm):
    """Demo 2FA one-time-password verification form."""

    otp_code = StringField(
        "One-Time Password",
        validators=[
            DataRequired(),
            Length(min=6, max=6, message="Enter the 6-digit code."),
            Regexp(r"^\d{6}$", message="OTP must be numeric."),
        ],
    )
    submit = SubmitField("Verify Code")


class ForgotPasswordForm(FlaskForm):
    """Request a password reset link via (mock) email."""

    email = StringField("Email", validators=[DataRequired(), Email()])
    submit = SubmitField("Send Reset Link")


class ResetPasswordForm(FlaskForm):
    """Set a new password using a valid reset token."""

    password = PasswordField(
        "New Password",
        validators=[DataRequired(), validate_strong_password],
    )
    confirm_password = PasswordField(
        "Confirm New Password",
        validators=[DataRequired(), EqualTo("password", message="Passwords must match.")],
    )
    submit = SubmitField("Reset Password")


class ChangePasswordForm(FlaskForm):
    """Change password from within the profile page (requires current password)."""

    current_password = PasswordField("Current Password", validators=[DataRequired()])
    new_password = PasswordField(
        "New Password",
        validators=[DataRequired(), validate_strong_password],
    )
    confirm_new_password = PasswordField(
        "Confirm New Password",
        validators=[DataRequired(), EqualTo("new_password", message="Passwords must match.")],
    )
    submit = SubmitField("Update Password")


class UpdateProfileForm(FlaskForm):
    """Update basic profile info (username / email)."""

    username = StringField(
        "Username",
        validators=[
            DataRequired(),
            Length(min=3, max=25),
            Regexp(r"^[A-Za-z0-9_]+$", message="Letters, numbers, underscores only."),
        ],
    )
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    submit = SubmitField("Save Changes")


class DeleteAccountForm(FlaskForm):
    """Confirm account deletion by re-entering the password."""

    password = PasswordField("Confirm Password", validators=[DataRequired()])
    submit = SubmitField("Delete My Account")
