"""
routes.py
---------
All application view functions, organized on a Blueprint.

Security notes:
- Every route that mutates state is POST-only and CSRF-protected (via Flask-WTF forms).
- All DB access goes through SQLAlchemy ORM calls -> parameterized queries -> no SQL injection.
- All user-supplied strings rendered in Jinja2 templates are auto-escaped -> mitigates XSS.
- Sensitive routes require @login_required.
- Login endpoint is rate-limited and enforces account lockout after repeated failures.
"""

from datetime import datetime

from flask import (
    Blueprint,
    render_template,
    redirect,
    url_for,
    flash,
    request,
    session,
    current_app,
)
from flask_login import (
    login_user,
    logout_user,
    login_required,
    current_user,
)

from extensions import db, limiter
from models import User
from forms import (
    RegisterForm,
    LoginForm,
    OTPForm,
    ForgotPasswordForm,
    ResetPasswordForm,
    ChangePasswordForm,
    UpdateProfileForm,
    DeleteAccountForm,
)

main_bp = Blueprint("main", __name__)


# ----------------------------------------------------------------------
# Mock email sender (demo implementation - prints to console)
# ----------------------------------------------------------------------
def send_mock_email(to_address: str, subject: str, body: str) -> None:
    """
    Mock email implementation. In production, replace this with a real
    email provider (e.g. Flask-Mail + SMTP, SendGrid, SES, etc.).
    """
    current_app.logger.info(
        "\n----- MOCK EMAIL -----\nTo: %s\nSubject: %s\n\n%s\n-----------------------\n",
        to_address,
        subject,
        body,
    )


# ----------------------------------------------------------------------
# Public pages
# ----------------------------------------------------------------------
@main_bp.route("/")
def index():
    """Landing page: features, security overview, login/register CTAs."""
    return render_template("index.html")


# ----------------------------------------------------------------------
# Registration
# ----------------------------------------------------------------------
@main_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    form = RegisterForm()

    if form.validate_on_submit():
        # Uniqueness checks (ORM query -> parameterized, safe from SQLi)
        existing_user = User.query.filter(
            (User.email == form.email.data.lower()) | (User.username == form.username.data)
        ).first()

        if existing_user:
            flash("An account with that username or email already exists.", "danger")
            return render_template("register.html", form=form)

        user = User(
            username=form.username.data.strip(),
            email=form.email.data.lower().strip(),
        )
        user.set_password(form.password.data)
        token = user.generate_verification_token()

        db.session.add(user)
        db.session.commit()

        # Mock verification email
        verify_url = url_for("main.verify_email", token=token, _external=True)
        send_mock_email(
            user.email,
            "Verify your Secure Login System account",
            f"Hi {user.username},\n\nPlease verify your email by visiting:\n{verify_url}",
        )

        flash("Account created successfully! Please check your (mock) email to verify your account, then log in.", "success")
        return redirect(url_for("main.login"))

    return render_template("register.html", form=form)


@main_bp.route("/verify-email/<token>")
def verify_email(token):
    """Mock email verification endpoint."""
    user = User.query.filter_by(verification_token=token).first()
    if user:
        user.is_verified = True
        user.verification_token = None
        db.session.commit()
        flash("Email verified successfully! You can now log in.", "success")
    else:
        flash("Invalid or expired verification link.", "danger")
    return redirect(url_for("main.login"))


# ----------------------------------------------------------------------
# Login (+ demo 2FA step) with rate limiting & account lockout
# ----------------------------------------------------------------------
@main_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("10 per minute")  # Basic rate limiting against brute-force
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    form = LoginForm()

    if form.validate_on_submit():
        email = form.email.data.lower().strip()
        user = User.query.filter_by(email=email).first()

        # Generic error message (do not reveal whether email exists) to prevent user enumeration
        generic_error = "Invalid email or password."

        if not user:
            flash(generic_error, "danger")
            return render_template("login.html", form=form)

        if user.is_locked():
            minutes_left = max(
                1, int((user.account_locked_until - datetime.utcnow()).total_seconds() // 60) + 1
            )
            flash(
                f"Account locked due to too many failed attempts. Try again in {minutes_left} minute(s).",
                "danger",
            )
            return render_template("login.html", form=form)

        if user.check_password(form.password.data):
            # Successful password check -> reset lockout counters
            user.reset_failed_attempts()

            # Trigger demo OTP (2FA) instead of logging in immediately
            otp = user.generate_otp(current_app.config["OTP_EXPIRY_MINUTES"])
            db.session.commit()

            send_mock_email(
                user.email,
                "Your Secure Login System OTP Code",
                f"Your one-time password is: {otp}\nIt expires in "
                f"{current_app.config['OTP_EXPIRY_MINUTES']} minutes.",
            )

            # Stash pending-login state in the (signed, server-verified) session
            session["pending_user_id"] = user.id
            session["remember_me"] = bool(form.remember.data)

            flash("A one-time password has been sent to your email (see server console for demo).", "info")
            return redirect(url_for("main.verify_otp"))
        else:
            user.register_failed_attempt(
                current_app.config["MAX_FAILED_LOGIN_ATTEMPTS"],
                current_app.config["ACCOUNT_LOCK_MINUTES"],
            )
            db.session.commit()

            remaining = current_app.config["MAX_FAILED_LOGIN_ATTEMPTS"] - user.failed_attempts
            if remaining > 0:
                flash(f"{generic_error} ({remaining} attempt(s) remaining before lockout)", "danger")
            else:
                flash(
                    f"Account locked for {current_app.config['ACCOUNT_LOCK_MINUTES']} minutes "
                    "due to too many failed attempts.",
                    "danger",
                )
            return render_template("login.html", form=form)

    return render_template("login.html", form=form)


@main_bp.route("/verify-otp", methods=["GET", "POST"])
@limiter.limit("10 per minute")
def verify_otp():
    """Second factor: verify the demo OTP code before completing login."""
    pending_user_id = session.get("pending_user_id")
    if not pending_user_id:
        flash("Please log in first.", "warning")
        return redirect(url_for("main.login"))

    user = User.query.get(pending_user_id)
    if not user:
        session.pop("pending_user_id", None)
        flash("Session expired. Please log in again.", "warning")
        return redirect(url_for("main.login"))

    form = OTPForm()

    if form.validate_on_submit():
        if user.verify_otp(form.otp_code.data):
            user.last_login = datetime.utcnow()
            db.session.commit()

            remember = session.pop("remember_me", False)
            session.pop("pending_user_id", None)

            login_user(user, remember=remember)
            flash(f"Welcome back, {user.username}!", "success")
            return redirect(url_for("main.dashboard"))
        else:
            flash("Invalid or expired OTP code. Please try again.", "danger")

    return render_template("verify_otp.html", form=form)


# ----------------------------------------------------------------------
# Logout
# ----------------------------------------------------------------------
@main_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out successfully.", "info")
    return redirect(url_for("main.index"))


# ----------------------------------------------------------------------
# Dashboard
# ----------------------------------------------------------------------
@main_bp.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", user=current_user)


# ----------------------------------------------------------------------
# Profile: update info, change password, delete account
# ----------------------------------------------------------------------
@main_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    update_form = UpdateProfileForm(prefix="update")
    password_form = ChangePasswordForm(prefix="pwd")
    delete_form = DeleteAccountForm(prefix="del")

    if request.method == "GET":
        update_form.username.data = current_user.username
        update_form.email.data = current_user.email

    return render_template(
        "profile.html",
        user=current_user,
        update_form=update_form,
        password_form=password_form,
        delete_form=delete_form,
    )


@main_bp.route("/profile/update", methods=["POST"])
@login_required
def update_profile():
    form = UpdateProfileForm(prefix="update")
    if form.validate_on_submit():
        new_username = form.username.data.strip()
        new_email = form.email.data.lower().strip()

        conflict = User.query.filter(
            User.id != current_user.id,
            (User.username == new_username) | (User.email == new_email),
        ).first()

        if conflict:
            flash("That username or email is already taken.", "danger")
        else:
            current_user.username = new_username
            current_user.email = new_email
            db.session.commit()
            flash("Profile updated successfully.", "success")
    else:
        for field_errors in form.errors.values():
            for err in field_errors:
                flash(err, "danger")

    return redirect(url_for("main.profile"))


@main_bp.route("/profile/change-password", methods=["POST"])
@login_required
def change_password():
    form = ChangePasswordForm(prefix="pwd")
    if form.validate_on_submit():
        if not current_user.check_password(form.current_password.data):
            flash("Current password is incorrect.", "danger")
        else:
            current_user.set_password(form.new_password.data)
            db.session.commit()
            flash("Password updated successfully.", "success")
    else:
        for field_errors in form.errors.values():
            for err in field_errors:
                flash(err, "danger")

    return redirect(url_for("main.profile"))


@main_bp.route("/profile/delete", methods=["POST"])
@login_required
def delete_account():
    form = DeleteAccountForm(prefix="del")
    if form.validate_on_submit():
        if not current_user.check_password(form.password.data):
            flash("Incorrect password. Account not deleted.", "danger")
            return redirect(url_for("main.profile"))

        user = current_user
        logout_user()
        db.session.delete(user)
        db.session.commit()
        flash("Your account has been permanently deleted.", "info")
        return redirect(url_for("main.index"))
    else:
        for field_errors in form.errors.values():
            for err in field_errors:
                flash(err, "danger")
        return redirect(url_for("main.profile"))


# ----------------------------------------------------------------------
# Forgot / Reset password
# ----------------------------------------------------------------------
@main_bp.route("/forgot-password", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def forgot_password():
    form = ForgotPasswordForm()

    if form.validate_on_submit():
        email = form.email.data.lower().strip()
        user = User.query.filter_by(email=email).first()

        # Always show the same message to avoid leaking which emails are registered
        flash("If that email exists in our system, a password reset link has been sent.", "info")

        if user:
            token = user.generate_reset_token(current_app.config["PASSWORD_RESET_EXPIRY_MINUTES"])
            db.session.commit()
            reset_url = url_for("main.reset_password", token=token, _external=True)
            send_mock_email(
                user.email,
                "Reset your Secure Login System password",
                f"Hi {user.username},\n\nReset your password using this link "
                f"(valid {current_app.config['PASSWORD_RESET_EXPIRY_MINUTES']} minutes):\n{reset_url}",
            )

        return redirect(url_for("main.login"))

    return render_template("forgot_password.html", form=form)


@main_bp.route("/reset-password/<token>", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def reset_password(token):
    user = User.query.filter_by(reset_token=token).first()

    if not user or not user.is_reset_token_valid(token):
        flash("Invalid or expired password reset link.", "danger")
        return redirect(url_for("main.forgot_password"))

    form = ResetPasswordForm()

    if form.validate_on_submit():
        user.set_password(form.password.data)
        user.clear_reset_token()
        user.reset_failed_attempts()
        db.session.commit()
        flash("Password reset successfully. Please log in with your new password.", "success")
        return redirect(url_for("main.login"))

    return render_template("reset_password.html", form=form, token=token)


# ----------------------------------------------------------------------
# Error handlers (registered in app.py)
# ----------------------------------------------------------------------
def page_not_found(e):
    return render_template("404.html"), 404


def internal_server_error(e):
    db.session.rollback()  # ensure a clean session after unexpected errors
    return render_template("500.html"), 500
