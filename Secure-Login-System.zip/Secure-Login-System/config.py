"""
config.py
---------
Centralized application configuration.
Loads sensitive values from environment variables (.env) so secrets
never live in source control.
"""

import os
from datetime import timedelta
from dotenv import load_dotenv

# Load variables from a .env file into the process environment
load_dotenv()

# Base directory of the project
BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    """Base configuration shared by all environments."""

    # --- Core Flask ---
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-in-your-.env-file")

    # --- Database ---
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'database.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # --- Session / Cookie security ---
    SESSION_COOKIE_HTTPONLY = True          # JS cannot read the cookie (mitigates XSS theft)
    SESSION_COOKIE_SAMESITE = "Lax"         # CSRF mitigation
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "False") == "True"
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_DURATION = timedelta(days=14)
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=30)

    # --- CSRF ---
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = None  # tokens valid for the whole session

    # --- Account lockout policy ---
    MAX_FAILED_LOGIN_ATTEMPTS = 5
    ACCOUNT_LOCK_MINUTES = 15

    # --- Rate limiting ---
    RATELIMIT_DEFAULT = "200 per day;50 per hour"
    RATELIMIT_STORAGE_URI = "memory://"

    # --- Mock email / OTP settings ---
    MAIL_SENDER = os.environ.get("MAIL_SENDER", "no-reply@securelogin.local")
    OTP_EXPIRY_MINUTES = 5
    PASSWORD_RESET_EXPIRY_MINUTES = 30


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False
    SESSION_COOKIE_SECURE = True


config_map = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}
