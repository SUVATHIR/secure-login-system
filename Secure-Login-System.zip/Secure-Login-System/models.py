"""
models.py
---------
SQLAlchemy ORM models.

Using an ORM (instead of raw SQL strings) is itself a core defense against
SQL Injection: all queries are parameterized automatically by SQLAlchemy.
"""

import secrets
from datetime import datetime, timedelta

import bcrypt
from flask_login import UserMixin

from extensions import db


class User(UserMixin, db.Model):
    """Represents an application user / account."""

    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(128), nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)

    # --- Brute-force / lockout tracking ---
    failed_attempts = db.Column(db.Integer, default=0, nullable=False)
    account_locked_until = db.Column(db.DateTime, nullable=True)

    # --- Mock email verification ---
    is_verified = db.Column(db.Boolean, default=False, nullable=False)
    verification_token = db.Column(db.String(64), nullable=True)

    # --- Password reset ---
    reset_token = db.Column(db.String(64), nullable=True)
    reset_token_expiry = db.Column(db.DateTime, nullable=True)

    # --- 2FA (demo OTP) ---
    otp_code = db.Column(db.String(6), nullable=True)
    otp_expiry = db.Column(db.DateTime, nullable=True)
    otp_enabled = db.Column(db.Boolean, default=True, nullable=False)

    # --- Account status ---
    is_active_account = db.Column(db.Boolean, default=True, nullable=False)

    # ------------------------------------------------------------------
    # Password helpers
    # ------------------------------------------------------------------
    def set_password(self, plain_password: str) -> None:
        """Hash and store the given plain-text password using bcrypt."""
        hashed = bcrypt.hashpw(plain_password.encode("utf-8"), bcrypt.gensalt())
        self.password_hash = hashed.decode("utf-8")

    def check_password(self, plain_password: str) -> bool:
        """Verify a plain-text password against the stored bcrypt hash."""
        try:
            return bcrypt.checkpw(
                plain_password.encode("utf-8"), self.password_hash.encode("utf-8")
            )
        except (ValueError, AttributeError):
            return False

    # ------------------------------------------------------------------
    # Account lockout helpers
    # ------------------------------------------------------------------
    def is_locked(self) -> bool:
        """True if the account is currently within its lockout window."""
        if self.account_locked_until and self.account_locked_until > datetime.utcnow():
            return True
        return False

    def register_failed_attempt(self, max_attempts: int, lock_minutes: int) -> None:
        """Increment failed attempts and lock the account if threshold is hit."""
        self.failed_attempts = (self.failed_attempts or 0) + 1
        if self.failed_attempts >= max_attempts:
            self.account_locked_until = datetime.utcnow() + timedelta(minutes=lock_minutes)

    def reset_failed_attempts(self) -> None:
        """Clear failed-attempt counters after a successful login."""
        self.failed_attempts = 0
        self.account_locked_until = None

    # ------------------------------------------------------------------
    # Token helpers (verification / reset / OTP)
    # ------------------------------------------------------------------
    def generate_verification_token(self) -> str:
        self.verification_token = secrets.token_urlsafe(32)
        return self.verification_token

    def generate_reset_token(self, expiry_minutes: int) -> str:
        self.reset_token = secrets.token_urlsafe(32)
        self.reset_token_expiry = datetime.utcnow() + timedelta(minutes=expiry_minutes)
        return self.reset_token

    def is_reset_token_valid(self, token: str) -> bool:
        return (
            self.reset_token
            and self.reset_token == token
            and self.reset_token_expiry
            and self.reset_token_expiry > datetime.utcnow()
        )

    def clear_reset_token(self) -> None:
        self.reset_token = None
        self.reset_token_expiry = None

    def generate_otp(self, expiry_minutes: int) -> str:
        """Generate a 6-digit numeric OTP for demo 2FA."""
        otp = f"{secrets.randbelow(1_000_000):06d}"
        self.otp_code = otp
        self.otp_expiry = datetime.utcnow() + timedelta(minutes=expiry_minutes)
        return otp

    def verify_otp(self, code: str) -> bool:
        valid = (
            self.otp_code
            and self.otp_code == code
            and self.otp_expiry
            and self.otp_expiry > datetime.utcnow()
        )
        if valid:
            self.otp_code = None
            self.otp_expiry = None
        return bool(valid)

    def __repr__(self) -> str:
        return f"<User {self.username!r}>"
