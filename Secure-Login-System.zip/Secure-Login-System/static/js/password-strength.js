/**
 * password-strength.js
 * ---------------------
 * Client-side password strength indicator for UX feedback only.
 * The server (forms.py -> validate_strong_password) is the source of truth;
 * this script never replaces server-side validation.
 */

document.addEventListener("DOMContentLoaded", () => {
    const passwordField = document.getElementById("passwordField") || document.getElementById("newPasswordField");
    const fill = document.getElementById("pwdStrengthFill");

    if (!passwordField || !fill) return;

    const scorePassword = (pwd) => {
        let score = 0;
        if (pwd.length >= 8) score += 1;
        if (/[A-Z]/.test(pwd)) score += 1;
        if (/[a-z]/.test(pwd)) score += 1;
        if (/[0-9]/.test(pwd)) score += 1;
        if (/[^A-Za-z0-9]/.test(pwd)) score += 1;
        return score;
    };

    const colors = ["#ef4444", "#f97316", "#eab308", "#22c55e", "#16a34a"];

    passwordField.addEventListener("input", () => {
        const score = scorePassword(passwordField.value);
        const percent = (score / 5) * 100;
        fill.style.width = `${percent}%`;
        fill.style.backgroundColor = colors[Math.max(score - 1, 0)];
    });
});
