"""
app.py
------
Application factory and entrypoint.

Run with:
    python app.py
"""

import os
import click

from flask import Flask

from config import config_map
from extensions import db, login_manager, csrf, limiter
from routes import main_bp, page_not_found, internal_server_error


def create_app(config_name: str = None) -> Flask:
    """Application factory: builds and configures the Flask app instance."""

    if config_name is None:
        config_name = os.environ.get("FLASK_ENV", "development")

    app = Flask(__name__)
    app.config.from_object(config_map.get(config_name, config_map["default"]))

    # --- Initialize extensions ---
    db.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)

    login_manager.init_app(app)
    login_manager.login_view = "main.login"
    login_manager.login_message = "Please log in to access this page."
    login_manager.login_message_category = "warning"

    # --- User loader for Flask-Login ---
    from models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # --- Register blueprint & error handlers ---
    app.register_blueprint(main_bp)
    app.register_error_handler(404, page_not_found)
    app.register_error_handler(500, internal_server_error)

    # --- Security headers applied to every response ---
    @app.after_request
    def set_secure_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "font-src 'self' https://cdnjs.cloudflare.com; "
            "img-src 'self' data:;"
        )
        return response

    # --- CLI helper: create database tables ---
    @app.cli.command("init-db")
    def init_db():
        """Initialize the database (flask init-db)."""
        with app.app_context():
            db.create_all()
        click.echo("Database initialized.")

    return app


app = create_app()

if __name__ == "__main__":
    # Ensure tables exist on first run
    with app.app_context():
        db.create_all()

    # debug should be False in production; controlled via FLASK_ENV / config
    app.run(host="0.0.0.0", port=5000, debug=app.config.get("DEBUG", False))
