# 🔐 Secure Login System

A production-ready, full-stack authentication web application built with **Flask**, demonstrating industry-standard security practices for user registration, login, session management, and account protection.

![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)
![Flask](https://img.shields.io/badge/Flask-3.x-black.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)

---

## 📖 Project Overview

Secure Login System is a self-contained demo/portfolio project showing how to build a secure authentication flow from scratch using Flask, SQLAlchemy, and Bootstrap 5. It goes beyond a basic login form to include account lockout, rate limiting, demo two-factor authentication (OTP), password reset tokens, and a modern glassmorphism UI with dark mode.

It is intended as:
- A learning resource for secure web-app authentication patterns.
- A solid boilerplate/starter kit for real projects (swap the mock email sender for a real provider and you're most of the way to production).

---

## ✨ Features

### Core Authentication
- User registration with server-side validation
- Secure login with **Remember Me**
- Logout with full session teardown
- Session-based authentication via Flask-Login

### Pages
- **Home** — landing page, features, security overview, CTAs
- **Register** — username, email, password, confirm password
- **Login** — email, password, remember me
- **Two-Factor Verification** — demo OTP step after password check
- **Dashboard** — welcome message, profile summary, last login, account status
- **Profile** — update profile, change password, delete account
- **Forgot Password** / **Reset Password** — token-based flow
- **404 / 500** — custom branded error pages

### UI/UX
- Modern glassmorphism design with Bootstrap 5
- Light/Dark mode toggle (persisted client-side)
- Smooth fade-in animations
- Fully responsive layout
- Bootstrap Icons throughout
- Live password-strength meter

---

## 🛡️ Security Features

| Feature | Implementation |
|---|---|
| **Password Hashing** | `bcrypt` — passwords are never stored in plain text |
| **Password Policy** | Min 8 chars, uppercase, lowercase, number, special character (enforced server-side in `forms.py`) |
| **CSRF Protection** | `Flask-WTF` CSRF tokens on every form |
| **SQL Injection Protection** | 100% SQLAlchemy ORM — no raw string-interpolated SQL |
| **XSS Protection** | Jinja2 auto-escaping + `Content-Security-Policy` header |
| **Secure Session Cookies** | `HttpOnly`, `SameSite=Lax`, optional `Secure` flag (enable in production over HTTPS) |
| **Rate Limiting** | `Flask-Limiter` restricts login/reset attempts per IP |
| **Account Lockout** | Account locks for **15 minutes** after **5 failed login attempts** |
| **Generic Error Messages** | Login/reset flows avoid leaking whether an email is registered (mitigates user enumeration) |
| **Security Headers** | `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, CSP set on every response |
| **Email Verification** | Mock implementation (token-based, logged to console) |
| **Password Reset** | Expiring, single-use token sent via mock email |
| **Two-Factor Auth (2FA)** | Demo OTP (6-digit code, 5-minute expiry) required after password check |

> ⚠️ **Note:** Email sending is mocked (printed to the server console/log) for demo purposes. Replace `send_mock_email()` in `routes.py` with a real provider (Flask-Mail, SendGrid, SES, etc.) before using in production.

---

## 🧰 Technologies Used

- **Backend:** Python, Flask
- **Frontend:** HTML5, CSS3, JavaScript (vanilla), Bootstrap 5, Bootstrap Icons
- **Database:** SQLite
- **ORM:** SQLAlchemy (via Flask-SQLAlchemy)
- **Auth:** Flask-Login
- **Forms/CSRF:** Flask-WTF, WTForms
- **Password Hashing:** bcrypt
- **Rate Limiting:** Flask-Limiter
- **Config:** python-dotenv

---

## 📂 Folder Structure

```
Secure-Login-System/
│
├── app.py                  # Application factory & entrypoint
├── config.py                # Environment-based configuration
├── extensions.py             # Shared Flask extension instances
├── models.py                 # SQLAlchemy models (User)
├── forms.py                  # Flask-WTF forms & validators
├── routes.py                  # All view functions / blueprint
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
├── static/
│   ├── css/style.css
│   ├── js/main.js
│   └── js/password-strength.js
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── verify_otp.html
│   ├── dashboard.html
│   ├── profile.html
│   ├── forgot_password.html
│   ├── reset_password.html
│   ├── 404.html
│   └── 500.html
└── screenshots/
```

---

## ⚙️ Installation

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/Secure-Login-System.git
cd Secure-Login-System
```

### 2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure environment variables
```bash
cp .env.example .env
# then edit .env and set a strong SECRET_KEY, e.g.:
python -c "import secrets; print(secrets.token_hex(32))"
```

---

## ▶️ Running the Application

```bash
python app.py
```

The app will automatically create `database.db` (SQLite) on first run and start at:

```
http://127.0.0.1:5000
```

**Demo 2FA tip:** After entering your password, the OTP code is printed to the terminal/console (mock email) — copy it into the verification page.

---

## 🖼️ Screenshots

> Add your own screenshots to the `screenshots/` folder and reference them here, e.g.:
>
> `![Dashboard](screenshots/dashboard.png)`

---

## 🚀 Future Improvements

- Integrate a real transactional email provider (SendGrid / SES / Flask-Mail + SMTP)
- Add OAuth / social login (Google, GitHub)
- Add real TOTP-based 2FA (e.g. `pyotp` + authenticator apps) instead of email OTP
- Add admin dashboard for user management
- Add audit logging for security-relevant events
- Add automated test suite (pytest) and CI pipeline
- Migrate to PostgreSQL for production deployments
- Add Docker support

---

## 📜 License

This project is licensed under the **MIT License** — free to use, modify, and distribute for personal or commercial projects.

---

## 🧭 Git: Initialize, Commit & Push to GitHub

```bash
# Initialize a new git repository
git init

# Add all files
git add .

# Create the first commit
git commit -m "Initial commit: Secure Login System"

# Rename branch to main (if needed)
git branch -M main

# Link to your GitHub repository (create it on GitHub first)
git remote add origin https://github.com/<your-username>/Secure-Login-System.git

# Push to GitHub
git push -u origin main
```

---

Built with ❤️ and a security-first mindset.
