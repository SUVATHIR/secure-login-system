"""
extensions.py
-------------
Instantiate Flask extensions here (without binding to an app) so that
models.py, forms.py, and routes.py can all import them without causing
circular-import problems. app.py calls .init_app(app) on each of these.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

db = SQLAlchemy()
login_manager = LoginManager()
csrf = CSRFProtect()
limiter = Limiter(key_func=get_remote_address)
