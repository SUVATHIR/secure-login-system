/**
 * main.js
 * -------
 * Handles: dark mode toggle (persisted in-memory + localStorage),
 * and show/hide password buttons.
 */

document.addEventListener("DOMContentLoaded", () => {
    const root = document.documentElement;
    const themeToggle = document.getElementById("themeToggle");
    const themeIcon = document.getElementById("themeIcon");

    const applyTheme = (theme) => {
        root.setAttribute("data-bs-theme", theme);
        if (themeIcon) {
            themeIcon.className = theme === "dark" ? "bi bi-sun-fill" : "bi bi-moon-stars-fill";
        }
    };

    // Restore saved theme preference
    const savedTheme = localStorage.getItem("theme") || "light";
    applyTheme(savedTheme);

    if (themeToggle) {
        themeToggle.addEventListener("click", () => {
            const current = root.getAttribute("data-bs-theme");
            const next = current === "dark" ? "light" : "dark";
            applyTheme(next);
            localStorage.setItem("theme", next);
        });
    }

    // Show / hide password toggles
    document.querySelectorAll(".toggle-password").forEach((btn) => {
        btn.addEventListener("click", () => {
            const targetId = btn.getAttribute("data-target");
            const field = document.getElementById(targetId);
            if (!field) return;
            const icon = btn.querySelector("i");
            if (field.type === "password") {
                field.type = "text";
                icon.className = "bi bi-eye-slash";
            } else {
                field.type = "password";
                icon.className = "bi bi-eye";
            }
        });
    });

    // Auto-dismiss flash messages after 6 seconds
    document.querySelectorAll(".alert").forEach((alert) => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            bsAlert.close();
        }, 6000);
    });
});
